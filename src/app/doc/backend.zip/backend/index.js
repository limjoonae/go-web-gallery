'use strict';

const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
var fs = require('fs');

const app = express();
app.use(cors());

const upload = multer({
  dest: 'uploads/',
  storage: multer.diskStorage({
	  destination: function (req, file, cb) {
		cb(null, './uploads')
	  },
    filename: (req, file, cb) => {
      let ext = path.extname(file.originalname);
      cb(null, path.parse(file.originalname).name+'_'+`${Math.random().toString(36).substring(10)}${ext}`);
    }
  })
});

app.post('/upload', upload.any(), (req, res) => {
  res.json(req.files.map(file => {
	console.log('uploading',file.filename);
    let ext = path.extname(file.originalname);
    return {
      originalName: file.originalname,
      filename: file.filename
    }
  }));
});

app.get('/download', function(req, res){
	console.log(req);
	var name=req.body.file;
	var file = __dirname + '/uploads/' + name;
	res.download(file); // Set disposition and send it.
});

app.listen(10050, () => {
  console.log('ng2-uploader server running on port 10050.');
});